# SSH-PLUS 
# @SUDOAPTSU

PROJETO EM ANDAMENTO...

# UMA COPIA DA COPIA 👽

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/alfainternet/sshplus2/main/Plus && chmod 777 Plus && ./Plus
